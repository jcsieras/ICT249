<?php
class Enrollment extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
	}
	
	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		
		$student_id = $this->session->userdata('student_id');
		$_SESSION['student_id'] = $student_id;
		
		if(!isset($is_logged_in) || $is_logged_in != true )
		{
			echo 'You don\'t have permission to access this page. <a href="../">Login</a>';
			die();
		}
	}
	
	public function login() 
	{
		$data['content'] = 'login';
		$this->load->view('includes/template', $data);
	}
	
	public function login_failed() 
	{
		$data['content'] = 'login_failed';
		$this->load->view('includes/template', $data);
	}
	
	public function validate_credentials() 
	{
			$this->load->library('form_validation');
			$this->form_validation->set_rules('student_id', 'ID Number', 'trim|required');
			$this->form_validation->set_rules('password', 'Password', 'trim|required');
			
			if($this->form_validation->run() == FALSE) {
				$this->login(); 
			} 
			else { 
				$this->load->model('home_model');	
				$query = $this->home_model->validate('id');
			
					if($query == 1) {
						$data = array(
							'student_id' => $this->input->post('student_id'),
							'is_logged_in' => true
						);
						
						$this->session->set_userdata($data);
						redirect('enrollment/prf');
						
					}
					else {
						$this->login_failed();
					}
			}
			
	}
	
	public function prf() 
	{
		$this->is_logged_in();
		$this->load->model('enrollment_model');
		$data['query'] = $this->enrollment_model->student_details();
		
		$data['content'] = 'prf';
		$this->load->view('includes/template_member', $data);
	}
	
	public function subject_details() 
	{
		$this->is_logged_in();
		$this->load->model('enrollment_model');
		$data['query'] = $this->enrollment_model->subject_details();
		
		$data['content'] = 'subject_details';
		$this->load->view('includes/template_member', $data);
	}
	
	public function soa() 
	{
		$this->is_logged_in();
		$this->load->model('enrollment_model');
		$data['query'] = $this->enrollment_model->subject_details();
		
		$data['content'] = 'soa';
		$this->load->view('includes/template_member', $data);
	}
	
	public function cor() 
	{
		$this->is_logged_in();
		$this->load->model('enrollment_model');
		$data['query'] = $this->enrollment_model->student_details();
		
		$data['content'] = 'cor';
		$this->load->view('includes/template_member', $data);
	}
	
	public function cor_f() 
	{
		$this->is_logged_in();
		$this->load->model('enrollment_model');
		$data['query'] = $this->enrollment_model->student_details();
		
		$data['content'] = 'cor_f';
		$this->load->view('includes/template_member', $data);
	}
	
	public function subject_details_cor() 
	{
		$this->is_logged_in();
		$this->load->model('enrollment_model');
		$data['query'] = $this->enrollment_model->subject_details();
		
		$data['content'] = 'subject_details_cor';
		$this->load->view('includes/template_member', $data);
	}
	
	public function subject_details_cor_f() 
	{
		$this->is_logged_in();
		$this->load->model('enrollment_model');
		$data['query'] = $this->enrollment_model->subject_details();
		
		$data['content'] = 'subject_details_cor_f';
		$this->load->view('includes/template_member', $data);
	}
	
	
	
}
?>