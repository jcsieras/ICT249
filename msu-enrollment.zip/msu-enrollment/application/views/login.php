<!-- Login Page -->
    	<div data-role="page" data-theme="a" id="home">
    		<div data-role="header" data-theme="a" data-fullscreen="false" data-position="fixed"> 
            <a href="../home" data-role="button" data-icon="back" data-iconpos="notext"></a> 
            <p>AKAN ACCOUNT</p>	
    		</div>
   		  <div data-role="content">  
          	<div data-role="controlgroup">
                <?php
					$_SESSION['student_id'] = $this->input->post('student_id');
					
                    echo validation_errors('<p class="error">');
                    echo form_open('enrollment/validate_credentials');	
                    
                    echo form_label('ID Number: ', 'student_id');			   
                           echo '<p>'.form_input(array(
                            'name' => 'student_id',
                            'value' => $_SESSION['student_id'],
                            'placeholder' => 'ID Number',
                            'id' => 'student_id'
                           )).'</p>';
						   
                           
                    echo form_label('Password: ', 'password') ;			   
                           echo '<p>'.form_password(array(
                            'name' => 'password',
                            'value' => '',
                            'placeholder' => 'Password',
                            'id' => 'password'
                          )).'</p>';
						  
					echo form_submit('login', 'Submit');			   				   	
                ?>      
                </div>			
		</div>