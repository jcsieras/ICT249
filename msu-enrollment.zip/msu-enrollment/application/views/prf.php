<!-- PRF Page -->
    	<div data-role="page" data-theme="a" id="prf">
            <div data-role="header" data-theme="a" data-fullscreen="false" data-position="fixed">
            	<p align="center">PRELIMINARY REGISTRATION FORM</p>	
    		</div>
            
            <div data-role="content" data-theme="e"> 
            <div data-role="fieldcontain">
                <?php
					foreach($query as $row){
						$_SESSION['student_id'] = $row->student_id;
						$_SESSION['fname'] = $row->fname;
						$_SESSION['lname'] = $row->lname;
						$_SESSION['mname'] = $row->mname;
						$_SESSION['course'] = $row->course;
					}
                ?>
			
                <?php
				$today = date('Y-m-d');
					$query = $this->db->query('SELECT * FROM term 
						where start_date < "'.$today.'" order by start_date DESC limit 1');
							if ($query->num_rows() > 0) {			
								foreach ($query->result_array() as $row) {
										$term_id = $row['term_id'];
										$start_date = $row['start_date'];
										$school_yr = $row['school_yr'];
										$semester = $row['semester'];
								}
							}
				?>
                
                <?php
				$date_printed='0000-00-00';
					$query = $this->db->query('SELECT * FROM prf 
						where student_id = "'.$_SESSION['student_id'].'" 
						and term_id = "'.$term_id.'" ');
							if ($query->num_rows() > 0) {			
								foreach ($query->result_array() as $row) {
										$term_id = $row['term_id'];
										$date_printed = $row['date_printed'];
								}
							}
							
					if ($date_printed > 0)
					{
						redirect('enrollment/cor_f');
					}
				?>
                
            </div>
            
               <ul data-role="listview" data-split-theme="d">
               		<li><h1>PERSONAL DATA</h1></li>
                    <li>
                        <h2><strong>ID Number: </strong><?php echo $_SESSION['student_id']; ?></h2>	 
						<h2><strong>Full Name: </strong><?php echo $_SESSION['lname'].', '.$_SESSION['fname'].' '.$_SESSION['mname']; ?></h2>
                        <h2><strong>Course:</strong> <?php echo $_SESSION['course']; ?></h2>	 
						<h2><strong>Semester:</strong> <?php echo $semester; ?></h2>
                        <h2><strong>Academic Year:</strong> <?php echo $school_yr; ?></h2>
                    </li>
                </ul>

                <ul data-role="listview" data-split-icon="star" data-split-theme="d">
				<li ><h1>LIST OF ENROLLED SUBJECTS</h1></li>
                
                <?php
					
					$totalunits = 0;
					$tmpsubjid;
					$tmpsubjcode;
					$tmpsection;
					$tmpunits;
					$query = $this->db->query('SELECT * FROM enrollment
						where term_id = "'.$term_id.'"
						and student_id = "'.$_SESSION['student_id'].'" ');
							if ($query->num_rows() > 0) {			
								foreach ($query->result_array() as $row) {
										$enrollment_id = $row['enrollment_id'];
										$student_id = $row['student_id'];
										$term_id = $row['term_id'];
										$schedule_id = $row['schedule_id'];
										
										$query = $this->db->query('SELECT * FROM schedule
										where schedule_id = "'.$schedule_id.'" ');
											if ($query->num_rows() > 0) {			
												foreach ($query->result_array() as $row) {
														$subj_id = $row['subj_id'];
												}
											}
														
										$query = $this->db->query('SELECT * FROM subject
										where subj_id = "'.$subj_id.'" ');
											if ($query->num_rows() > 0) {			
												foreach ($query->result_array() as $row) {
														$subj_id = $row['subj_id'];
														$subj_code = $row['subj_code'];
														$tmpsubjid = $subj_id;
														$tmpsubjcode = $subj_code;
														
												}
											}	
											
										$query = $this->db->query('SELECT * FROM schedule
										where subj_id = "'.$subj_id.'" ');
											if ($query->num_rows() > 0) {			
												foreach ($query->result_array() as $row) {
														$section = $row['section'];
														$tmpsection = $section;
												}
											}	
											
										$query = $this->db->query('SELECT * FROM subject
										where subj_id = "'.$subj_id.'" ');
											if ($query->num_rows() > 0) {	
												foreach ($query->result_array() as $row) {
														$units = $row['units'];
														$totalunits += $units;
														$tmpunits = $units;
												}
											}
										echo '<li>
										
										<a href="subject_details?id='.$tmpsubjid.'">
										
										
										<h3>'.$tmpsubjcode.'</h3>
										<p>Section: '.$tmpsection.'</p>
										<p>Units: '.$tmpunits.'</p> </a>
										
										<a href="subject_details?id='.$tmpsubjid.'"></a></li>';
									}
							}
				?>
               
                </ul>
              </div>
                
                
                <ul data-role="listview" data-split-theme="d">
                    <li>
						<p><strong>Total Units Enrolled:</strong> <?php echo $totalunits; ?></p>	 
						<p><strong>Allowed Units:</strong> 21</p>
                        <p><strong>PRF Status:</strong>
							<?php
                            $query = $this->db->query('SELECT * FROM prf
                                                    where student_id = "'.$_SESSION['student_id'].'" 
                                                    and term_id = "'.$term_id.'" ');
                                                        if ($query->num_rows() > 0) {	
                                                            foreach ($query->result_array() as $row) {
                                                                    $prf_id = $row['prf_id'];
                                                                    $prf_stat = $row['prf_stat'];
                                                                    $date_printed = $row['date_printed'];
                                                                    echo $prf_stat;
                                                                    if ($date_printed > 0) {
                                                                        echo ' on '. $date_printed;
                                                                    }
                                                            }
                                                        }
                            
                            ?>
						<p>
					</li>
				</ul>
                
				<div><p></p></div>
                
                <footer data-role="footer" class="ui-bar" align="center">
                	<a href="../home/logout" data-transition="none">Logout</a>
                    <a href="soa">SOA</a>
                    <a href="cor">COR</a>
                    <p class="copyright">&copy; MSU-Marawi. All Rights Reserved.</p>
                </footer>
                          