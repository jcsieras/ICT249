<!-- Home Page -->
    	<div data-role="page" data-theme="a" id="home">
    		<div data-role="header" data-theme="a" data-fullscreen="false" data-position="fixed">
            <p>HOME</p>	  
    		</div>
   		  <div data-role="content">  
          	<img src="<?php echo base_url();?>images/logo.png" width="100" />
            <h1>MSU - Marawi <br />
            <span style="color:#149d43; font-size:18px;"><em>Enrollment Monitoring System</em></span></h1>
          
              <div data-role="controlgroup" data-theme="a">
                <a href="<?php echo base_url();?>index.php/enrollment/login" data-icon="arrow-r" data-icon="arrow-r" data-iconpos="right" data-transition="none" data-role="button" data-theme="a">LOGIN</a>      
              </div>
							
		</div>