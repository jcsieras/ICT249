<!-- SOA Page -->
    	<div data-role="page" data-theme="a" id="soa">
            <div data-role="header" data-theme="a" data-fullscreen="false" data-position="fixed">
            <a href="prf" data-role="button" data-icon="back" data-iconpos="notext"></a> 
            <p align="center">STATEMENT OF ACCOUNT</p>	
    		</div>
            
    		<div data-role="content" data-theme="e"> 
            <div data-role="fieldcontain">
				<?php
					foreach($query as $row){
						$_SESSION['student_id'] = $row->student_id;
						$_SESSION['fname'] = $row->fname;
						$_SESSION['lname'] = $row->lname;
						$_SESSION['mname'] = $row->mname;
						$_SESSION['course'] = $row->course;
					}
					
                ?>
                <?php
				$today = date('Y-m-d');
					$query = $this->db->query('SELECT * FROM term 
						where start_date < "'.$today.'" order by start_date DESC limit 1');
							if ($query->num_rows() > 0) {			
								foreach ($query->result_array() as $row) {
										$term_id = $row['term_id'];
										$start_date = $row['start_date'];
										$school_yr = $row['school_yr'];
										$semester = $row['semester'];
								}
							}
				?>
            </div>
            
            <?php
					$totaltuitionfee = 0;
					$totallabfee = 0;
					$query = $this->db->query('SELECT * FROM enrollment
						where term_id = "'.$term_id.'"
						and student_id = "'.$_SESSION['student_id'].'" ');
							if ($query->num_rows() > 0) {			
								foreach ($query->result_array() as $row) {
										$enrollment_id = $row['enrollment_id'];
										$student_id = $row['student_id'];
										$term_id = $row['term_id'];
										$schedule_id = $row['schedule_id'];
										
										$query = $this->db->query('SELECT * FROM schedule
										where schedule_id = "'.$schedule_id.'" ');
											if ($query->num_rows() > 0) {			
												foreach ($query->result_array() as $row) {
														$subj_id = $row['subj_id'];
												}
											}
											
										$query = $this->db->query('SELECT * FROM subject
										where subj_id = "'.$subj_id.'" ');
											if ($query->num_rows() > 0) {			
												foreach ($query->result_array() as $row) {
														$subj_id = $row['subj_id'];
														$subj_code = $row['subj_code'];
														$units = $row['units'];
														$lec_hours = $row['lec_hours'];
														$lec_rate = $row['lec_rate'];
														$lab_hours = $row['lab_hours'];
														$lab_rate = $row['lab_rate'];
														
														$totaltuitionfee += $lec_rate * $units;
														$totallabfee += $lab_rate;
												}
											}		
								}
							}
				?>
                
                <?php
					$id_fee = 0;
					$computer_fee = 0;
					$internet_fee = 0;
					$publication =0;
					$library = 0;
					$dental = 0;
					$insurance = 0;
					$totalmis = 0;
					$query = $this->db->query('SELECT * FROM miscellaneous 
						where term_id = "'.$term_id.'" ');
							if ($query->num_rows() > 0) {			
								foreach ($query->result_array() as $row) {
										$id_fee = $row['id_fee'];
										$computer_fee = $row['computer_fee'];
										$internet_fee = $row['internet_fee'];
										$publication = $row['publication'];
										$library = $row['library'];
										$dental = $row['dental'];
										$insurance = $row['insurance'];
										
										$totalmis = $id_fee + $computer_fee + $internet_fee + $publication
													 + $library + $dental + $insurance;
								}
							}
				?>
                
                
                <ul data-role="listview" data-split-theme="d" data-theme="e">
                    <li>
                    	<div class="ui-grid-a">
                            <div class="ui-block-a"><h3><strong>Tuition Fee: </strong></h3></div>
                            <div class="ui-block-b" align="right"><h3><?php echo $totaltuitionfee; ?></h3></div>	
                            <div class="ui-block-a"><h3><strong>ID Fee: </strong></h3></div>
                            <div class="ui-block-b" align="right"><h3><?php echo $id_fee; ?></h3></div>   
                            <div class="ui-block-a"><h3><strong>Computer Fee:</strong></h3></div>
                            <div class="ui-block-b" align="right"><h3><?php echo $computer_fee; ?></h3></div>   
                            <div class="ui-block-a"><h3><strong>Internet Fee:</strong></h3></div>
                            <div class="ui-block-b" align="right"><h3><?php echo $internet_fee; ?></h3></div> 
                            <div class="ui-block-a"><h3><strong>Laboratory Fee:</strong></h3></div>
                            <div class="ui-block-b" align="right"><h3><?php echo $totallabfee; ?></h3></div> 
                            <div class="ui-block-a"><h3><strong>Publication Fee:</strong></h3></div>
                            <div class="ui-block-b" align="right"><h3><?php echo $publication; ?></h3></div> 
                            <div class="ui-block-a"><h3><strong>Library Fee:</strong></h3></div>
                            <div class="ui-block-b" align="right"><h3><?php echo $library; ?></h3></div> 
                            <div class="ui-block-a"><h3><strong>Dental Fee:</strong></h3></div>
                            <div class="ui-block-b" align="right"><h3><?php echo $dental; ?></h3></div> 
                            <div class="ui-block-a"><h3><strong>Insurance Fee:</strong></h3></div>
                            <div class="ui-block-b" align="right"><h3><?php echo $insurance; ?></h3></div> 
                        </div>
                   </li>
				</ul>
                
                
                
                <ul data-role="listview" data-theme="a" >
                    <li>
                    	<div class="ui-grid-a">
                            <div class="ui-block-a"><h3><strong>Total: </strong></h3></div>
                            <div class="ui-block-b" align="right"><h3><?php echo $totalass = $totaltuitionfee + $totallabfee + $totalmis; ?></h3></div>
						</div>

                        <h3><strong><u>SOA Status:</u></strong>
                        	<?php
							$soa_stat = "Unpaid";
							$date_printed = '';
							$query = $this->db->query('SELECT * FROM soa
													where student_id = "'.$_SESSION['student_id'].'" 
													and term_id = "'.$term_id.'" ');
														if ($query->num_rows() > 0) {	
															foreach ($query->result_array() as $row) {
																	$soa_id = $row['soa_id'];
																	$soa_stat = $row['soa_stat'];
																	$date_printed = $row['date_printed'];
																	
															}
															
														}
														echo $soa_stat;
															if ($date_printed > 0) {
																echo ' on '. $date_printed;
															}
							
							?>
                        </h3>
                        
					</li>
				</ul>
                
                <?php
                $query = $this->db->query('SELECT * FROM soa 
										WHERE student_id = "'.$_SESSION['student_id'].'" ');
										
									foreach ($query->result_array() as $row) { 
											$soa_id = $row['soa_id'];
									}
										if ($query->num_rows() > 0) {
													$this->db->where('soa_id', $soa_id)
														->update('soa', array(
														'total' => $totalass	
														));
											}
										else {
												$new_member_insert_data = array(
														'total' => $totalass
														);
												$insert = $this->db->insert('soa', $new_member_insert_data);	
											}
				?>		
                </div>
                <div><p></p></div>					
                <footer data-role="footer" class="ui-bar" align="center">
                        <p class="copyright">&copy; MSU-Marawi. All Rights Reserved.</p>
                </footer>