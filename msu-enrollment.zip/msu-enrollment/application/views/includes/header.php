<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title></title>
<meta name="keywords" content="" />
<meta name="description" content="" />

		<meta charset="utf-8" />
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		
		<script src="<?php echo base_url();?>js/jquery-1.9.1.min.js"></script>
		<script src="<?php echo base_url();?>js/jquery.ui.map.min.js"></script>
		<script src="<?php echo base_url();?>js/jquery.mobile-1.3.1.min.js"></script>
        <link rel="stylesheet" href="<?php echo base_url();?>css/jquery.mobile-1.3.1.min.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/mystyle.css" />
	
        <script>
			    //onDeviceReady is called when PhoneGap is initial
			    function onDeviceReady() {        
				    $(document).ready(function() {            
				    //Call any jQuery functions here        
				    });
			    }
			    document.addEventListener("deviceready", onDeviceReady);
		</script> 

</head>
<body>

	
