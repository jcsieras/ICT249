    		<div data-role="footer" class="ui-bar" data-theme="a" data-position="fixed">
				<p class="copyright">&copy; MSU-Marawi. All Rights Reserved.</p>	
    		</div>
    	</div>
<!-- End of Home Page -->
 	
    
    </body>
</html>