<?php $this->load->view('includes/header_member'); ?>
<?php $this->load->view($content); ?>

