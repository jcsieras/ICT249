<!-- COR Page -->
    	<div data-role="page" data-theme="a" id="soa">
            <div data-role="header" data-theme="a" data-fullscreen="false" data-position="fixed">
            <a href="../home/logout" data-role="button">Logout</a>
            <p align="center">CERTIFICATE OF REGISTRATION</p>	
            <a href="soa" data-role="button">SOA</a>
    		</div>
            
    		<div data-role="content" data-theme="e"> 
            <div data-role="fieldcontain">
				<?php
					foreach($query as $row){
						$_SESSION['student_id'] = $row->student_id;
						$_SESSION['fname'] = $row->fname;
						$_SESSION['lname'] = $row->lname;
						$_SESSION['mname'] = $row->mname;
						$_SESSION['course'] = $row->course;
					}
                ?>
                <?php
				$today = date('Y-m-d');
					$query = $this->db->query('SELECT * FROM term 
						where start_date < "'.$today.'" order by start_date DESC limit 1');
							if ($query->num_rows() > 0) {			
								foreach ($query->result_array() as $row) {
										$term_id = $row['term_id'];
										$start_date = $row['start_date'];
										$school_yr = $row['school_yr'];
										$semester = $row['semester'];
								}
							}
				?>
            </div>
            
				 <ul data-role="listview" data-theme="e">
                    <li>
						<h2><strong>ID Number:</strong> <?php echo $_SESSION['student_id']; ?></h2>	 
						<h2><strong>Full Name:</strong> <?php echo $_SESSION['lname'].', '.$_SESSION['fname'].' '.$_SESSION['mname']; ?></h2>
                        <h2><strong>Course:</strong> <?php echo $_SESSION['course']; ?></h2>	 
                        <h2><strong>Academic Year:</strong> <?php echo $school_yr; ?></h2>
						<h2><strong>Semester:</strong> <?php echo $semester; ?></h2>
					</li>
				</ul>
                
            
                <ul data-role="listview" data-split-icon="star" data-split-theme="d" data-theme="e">
                <li ><h1>LIST OF ENROLLED SUBJECTS</h1></li>
                <?php
					$totalunits = 0;
					$query = $this->db->query('SELECT * FROM enrollment
						where term_id = "'.$term_id.'"
						and student_id = "'.$_SESSION['student_id'].'" ');
							if ($query->num_rows() > 0) {			
								foreach ($query->result_array() as $row) {
										$enrollment_id = $row['enrollment_id'];
										$student_id = $row['student_id'];
										$term_id = $row['term_id'];
										$schedule_id = $row['schedule_id'];
										
										$query = $this->db->query('SELECT * FROM schedule
										where schedule_id = "'.$schedule_id.'" ');
											if ($query->num_rows() > 0) {			
												foreach ($query->result_array() as $row) {
														$subj_id = $row['subj_id'];
												}
											}
											
										$query = $this->db->query('SELECT * FROM subject
										where subj_id = "'.$subj_id.'" ');
											if ($query->num_rows() > 0) {			
												foreach ($query->result_array() as $row) {
														$subj_id = $row['subj_id'];
														$subj_code = $row['subj_code'];
														echo '<li>
														<a href="subject_details?id='.$subj_id.'">
														<h3>'.$subj_code.'</h3>';
												}
											}	
											
										$query = $this->db->query('SELECT * FROM schedule
										where subj_id = "'.$subj_id.'" ');
											if ($query->num_rows() > 0) {			
												foreach ($query->result_array() as $row) {
														$section = $row['section'];
														echo '<p>Section: '.$section.'</p>';
												}
											}	
											
										$query = $this->db->query('SELECT * FROM subject
										where subj_id = "'.$subj_id.'" ');
											if ($query->num_rows() > 0) {	
												foreach ($query->result_array() as $row) {
														$units = $row['units'];
														$totalunits += $units;
														
														echo '<p>Units: '.$units.'</p> </a>
														<a href="subject_details?id='.$subj_id.'"></a></li>';
												}
											}	
								}
							}
				?>
                </div>
                
                <?php
                $query = $this->db->query('SELECT * FROM cor
										where student_id = "'.$student_id.'" 
										and term_id = "'.$term_id.'" ');
											if ($query->num_rows() > 0) {	
												foreach ($query->result_array() as $row) {
														$cor_id = $row['cor_id'];
														$cor_stat = $row['cor_stat'];
														$date_printed = $row['date_printed'];
												}
											}
                
                ?>
                
                <?php
                $query = $this->db->query('SELECT * FROM soa
										where student_id = "'.$student_id.'" 
										and term_id = "'.$term_id.'" ');
											if ($query->num_rows() > 0) {	
												foreach ($query->result_array() as $row) {
														$soa_id = $row['soa_id'];
														$soa_stat = $row['soa_stat'];
														$totalass = $row['total'];
														$date_printed = $row['date_printed'];
                                                         if ($date_printed > 0) {
                                                               $date_p = ' on '. $date_printed;
                                                         }
														 else {
															 $date_p = '';	
														 }
												}
											}
                
                ?>
                <ul data-role="listview" data-theme="e">
                    <li>
						<p><strong>Total Units Enrolled:</strong> <?php echo $totalunits; ?></p>	 
                        <p><strong>Total Assessment:</strong> <?php echo $totalass; ?></p>
                        <p><strong>COR Status:</strong> <?php echo $cor_stat.$date_p; ?></p>
					</li>
				</ul>
                <div><p></p></div>
                <footer data-role="footer" class="ui-bar" align="center">
                        <p class="copyright">&copy; MSU-Marawi. All Rights Reserved.</p>
                </footer>