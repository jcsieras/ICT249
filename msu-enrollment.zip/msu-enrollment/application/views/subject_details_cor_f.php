<!-- Subject Details Page -->
    	<div data-role="page" data-theme="a" id="subject_details_cor">
            <div data-role="header" data-theme="a" data-fullscreen="false" data-position="fixed">
            <a href="cor_f" data-role="button" data-icon="back" data-iconpos="notext"></a> 
            <p align="center">SUBJECT DETAILS</p>	
    		</div>
            
    		<div data-role="content" data-theme="e"> 
            <div data-role="fieldcontain">
				<?php
					foreach($query as $row){
						$_SESSION['subj_code'] = $row->subj_code;
						$_SESSION['title'] = $row->title;
						$_SESSION['units'] = $row->units;
						$_SESSION['lec_hours'] = $row->lec_hours;
						$_SESSION['lab_hours'] = $row->lab_hours;
						$_SESSION['lec_rate'] = $row->lec_rate;
						$_SESSION['lab_rate'] = $row->lab_rate;
						$_SESSION['section'] = $row->section;
						$_SESSION['day'] = $row->day;
						$_SESSION['time_'] = $row->time_;
						$_SESSION['room'] = $row->room;
						$_SESSION['instructor'] = $row->instructor;
						$_SESSION['subj_id'] = $row->subj_id;
					}
                ?>
            </div>
            
				 <ul data-role="listview" data-split-theme="d">
                    <li>
						<h1><strong>Code:</strong> <?php echo $_SESSION['subj_code']; ?></h1>	 
						<h2><strong>Title:</strong> <?php echo $_SESSION['title']; ?></h2>
                        <h2><strong>Section:</strong> <?php echo $_SESSION['section']; ?></h2>	 
						<h2><strong>Days:</strong> <?php echo $_SESSION['day']; ?></h2>
                        <h2><strong>Time:</strong> <?php echo $_SESSION['time_']; ?></h2>
                        <h2><strong>Room:</strong> <?php echo $_SESSION['room']; ?></h2>
                        <h2><strong>Lecture hours:</strong> <?php echo $_SESSION['lec_hours']; ?></h2>
                        <h2><strong>Laboratory hours:</strong> <?php echo $_SESSION['lab_hours']; ?></h2>
                        <h2><strong>Units:</strong> <?php echo $_SESSION['units']; ?></h2>
                        <h2><strong>Instructor:</strong> <?php echo $_SESSION['instructor']; ?></h2>
					</li>
				</ul>
            </div>

                <div><p></p></div>
                <footer data-role="footer" class="ui-bar" align="center">
                        <p class="copyright">&copy; MSU-Marawi. All Rights Reserved.</p>
                </footer>